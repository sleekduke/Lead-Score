import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, MapPin, Phone, Mail } from "lucide-react";
import { LeadScoreItem } from "./LeadScoreItem";

interface Score {
  label: string;
  score: number;
}

interface Lead {
  id: string;
  name: string;
  location: string;
  phone: string;
  email: string;
  overallMatch: number;
  scores: Score[];
}

interface LeadCardProps {
  lead: Lead;
}

export function LeadCard({ lead }: LeadCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-5 py-4 text-left"
      >
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
                {lead.name.charAt(0)}
              </div>
              <div>
                <h3 className="text-slate-900">{lead.name}</h3>
                <div className="flex items-center gap-1 text-slate-500 text-sm mt-0.5">
                  <MapPin className="w-3 h-3" />
                  <span>{lead.location}</span>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs text-slate-500 mb-1">Match Score</div>
              <div
                className={`text-lg ${
                  lead.overallMatch >= 70
                    ? "text-green-600"
                    : lead.overallMatch >= 50
                    ? "text-amber-600"
                    : "text-red-500"
                }`}
              >
                {lead.overallMatch}%
              </div>
            </div>
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.3 }}
            >
              <ChevronDown className="w-5 h-5 text-slate-400" />
            </motion.div>
          </div>
        </div>
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="overflow-hidden"
          >
            <div className="px-5 pb-5 border-t border-slate-100">
              <div className="pt-4 pb-2">
                <h4 className="text-sm text-slate-500 mb-1">Contact Information</h4>
                <div className="flex flex-col gap-2 mt-3">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Phone className="w-4 h-4 text-slate-400" />
                    <span>{lead.phone}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Mail className="w-4 h-4 text-slate-400" />
                    <span>{lead.email}</span>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100">
                <h4 className="text-sm text-slate-500 mb-3">Property Match Analysis</h4>
                <div className="space-y-1">
                  {lead.scores.map((score, index) => (
                    <LeadScoreItem
                      key={score.label}
                      label={score.label}
                      score={score.score}
                      index={index}
                    />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}