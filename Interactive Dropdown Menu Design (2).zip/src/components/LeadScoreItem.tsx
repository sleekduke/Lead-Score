import { motion } from "motion/react";

interface ScoreItemProps {
  label: string;
  score: number;
  index: number;
}

export function LeadScoreItem({ label, score, index }: ScoreItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      className="flex items-center justify-between gap-4 py-3"
    >
      <div className="flex-1">
        <div className="flex items-center justify-between mb-2">
          <span className="text-slate-700">{label}</span>
          <span className="text-slate-900">{score}%</span>
        </div>
        <div className="relative h-2 bg-slate-100 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${score}%` }}
            transition={{ delay: index * 0.05 + 0.2, duration: 0.6, ease: "easeOut" }}
            className={`h-full rounded-full ${
              score >= 70
                ? "bg-green-500"
                : score >= 50
                ? "bg-amber-500"
                : "bg-red-400"
            }`}
          />
        </div>
      </div>
      <div className="flex-shrink-0">
        <CircularScore score={score} />
      </div>
    </motion.div>
  );
}

function CircularScore({ score }: { score: number }) {
  const radius = 18;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  return (
    <div className="relative w-12 h-12">
      <svg className="w-full h-full -rotate-90" viewBox="0 0 44 44">
        <circle
          cx="22"
          cy="22"
          r={radius}
          fill="none"
          stroke="#f1f5f9"
          strokeWidth="4"
        />
        <motion.circle
          cx="22"
          cy="22"
          r={radius}
          fill="none"
          stroke={score >= 70 ? "#10b981" : score >= 50 ? "#f59e0b" : "#f87171"}
          strokeWidth="4"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          strokeLinecap="round"
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-[10px] text-slate-600">{score}</span>
      </div>
    </div>
  );
}
